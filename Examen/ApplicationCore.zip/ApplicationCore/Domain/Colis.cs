﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ApplicationCore.Domain
{
    public class Colis
    {
        public DateTime DateLivraison { get; set; }
        public double montant { get; set; }
        public double Poids { get; set; }
        public double Volume { get; set; }

        public virtual Client Client { get; set; }
        public virtual Livreur Livreur { get; set; }

        [ForeignKey("ClientFK")]
        public string ClientFK { get; set; }

        [ForeignKey("LivreurFK")]
        public string LivreurFK { get; set; }

    }
}
