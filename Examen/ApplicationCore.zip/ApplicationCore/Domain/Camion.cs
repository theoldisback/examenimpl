﻿namespace ApplicationCore.Domain
{
    public class Camion : Vehicule
    {
        public int capacite { get; set; }
        public int NbrEssieux { get; set; }
    }
}
