﻿namespace ApplicationCore.Domain
{
    public class Voiture : Vehicule
    {
        public int NbrPlaces { get; set; }
    }
}
